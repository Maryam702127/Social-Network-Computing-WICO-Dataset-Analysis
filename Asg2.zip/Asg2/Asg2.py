import numpy as np
import networkx as nx
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
from torch_geometric.nn import GCNConv, SAGEConv
import matplotlib.pyplot as plt
import random
import requests
import gzip
from matplotlib.patches import Patch
import pandas as pd
import csv

def load_facebook_data():
    """Load Facebook social network data"""
    print("Downloading Facebook data...")
    url = "https://snap.stanford.edu/data/facebook_combined.txt.gz"
    response = requests.get(url)
    with open("facebook_combined.txt.gz", "wb") as f:
        f.write(response.content)
    
    edges = []
    with gzip.open("facebook_combined.txt.gz", 'rt') as f:
        for line in f:
            if line.strip():
                node1, node2 = map(int, line.strip().split())
                edges.append((node1, node2))
    
    print(f"Loaded {len(edges)} edges")
    return edges

def get_connected_component(edges, target_size=600):
    """Get a connected component of specific size"""
    print("Creating connected component...")
    
    # Take a smaller sample first
    sample_size = min(20000, len(edges))
    sample_edges = random.sample(edges, sample_size)
    
    # Create graph from sample
    G_temp = nx.Graph()
    G_temp.add_edges_from(sample_edges)
    
    # Get largest connected component
    components = list(nx.connected_components(G_temp))
    if not components:
        components = [set(G_temp.nodes())]
    
    largest = max(components, key=len)
    print(f"Largest component has {len(largest)} nodes")
    
    # Take BFS sample from largest component to ensure connectivity
    if len(largest) > target_size:
        print(f"Taking BFS sample of {target_size} nodes...")
        start_node = random.choice(list(largest))
        visited = set([start_node])
        queue = [start_node]
        
        while queue and len(visited) < target_size:
            node = queue.pop(0)
            neighbors = list(G_temp.neighbors(node))
            random.shuffle(neighbors)
            
            for neighbor in neighbors:
                if neighbor in largest and neighbor not in visited and len(visited) < target_size:
                    visited.add(neighbor)
                    queue.append(neighbor)
        
        subset = visited
    else:
        subset = largest
    
    # Create subgraph
    G = G_temp.subgraph(subset).copy()
    
    # Rename nodes to 0,1,2,...
    nodes_sorted = sorted(G.nodes())
    mapping = {old: new for new, old in enumerate(nodes_sorted)}
    G = nx.relabel_nodes(G, mapping)
    
    print(f"Final connected component: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    return list(G.edges())

def create_graph_with_metrics(edges):
    """Create graph and compute all essential metrics"""
    G = nx.Graph()
    G.add_edges_from(edges)
    
    print("\n" + "="*60)
    print("COMPUTING ESSENTIAL GRAPH METRICS")
    print("="*60)
    
    print("\n1. DEGREE METRICS:")
    degrees = dict(G.degree())
    nx.set_node_attributes(G, degrees, 'degree')
    
    degree_values = list(degrees.values())
    print(f"    Average degree: {np.mean(degree_values):.2f}")
    print(f"    Maximum degree: {np.max(degree_values)}")
    print(f"    Minimum degree: {np.min(degree_values)}")
    
    # Top 5 nodes by degree
    top_degree_nodes = sorted(degrees.items(), key=lambda x: x[1], reverse=True)[:5]
    print(f"    Top 5 nodes by degree:")
    for node, deg in top_degree_nodes:
        print(f"     Node {node}: {deg} connections")
    
    print("\n2. CLUSTERING COEFFICIENT:")
    # Compute clustering coefficient for each node
    clustering = nx.clustering(G)
    nx.set_node_attributes(G, clustering, 'clustering')
    
    clustering_values = list(clustering.values())
    avg_clustering = np.mean(clustering_values)
    print(f"    Average clustering coefficient: {avg_clustering:.4f}")
    
    print("\n3. CENTRALITY MEASURES:")
    
    # Degree Centrality
    print("    Degree Centrality:")
    deg_centrality = nx.degree_centrality(G)
    nx.set_node_attributes(G, deg_centrality, 'degree_centrality')
    deg_centrality_values = list(deg_centrality.values())
    print(f"     Average: {np.mean(deg_centrality_values):.4f}")
    
    # Betweenness Centrality
    print("    Betweenness Centrality:")
    if G.number_of_nodes() > 500:
        nodes_sample = random.sample(list(G.nodes()), min(100, G.number_of_nodes()))
        betweenness = nx.betweenness_centrality_subset(G, nodes_sample, nodes_sample)
    else:
        betweenness = nx.betweenness_centrality(G, k=min(100, G.number_of_nodes()))
    nx.set_node_attributes(G, betweenness, 'betweenness')
    betweenness_values = list(betweenness.values())
    print(f"     Average: {np.mean(betweenness_values):.4f}")
    
    # Eigenvector Centrality
    print("    Eigenvector Centrality:")
    try:
        eigenvector = nx.eigenvector_centrality(G, max_iter=500, tol=1e-6)
        nx.set_node_attributes(G, eigenvector, 'eigenvector')
        eigenvector_values = list(eigenvector.values())
        print(f"     Average: {np.mean(eigenvector_values):.4f}")
    except:
        print("     Calculation failed, using PageRank as approximation")
        pagerank = nx.pagerank(G, alpha=0.85)
        nx.set_node_attributes(G, pagerank, 'eigenvector')
        eigenvector_values = list(pagerank.values())
        print(f"     Average: {np.mean(eigenvector_values):.6f}")
    
    # PageRank
    print("    PageRank:")
    pagerank = nx.pagerank(G, alpha=0.85)
    nx.set_node_attributes(G, pagerank, 'pagerank')
    pagerank_values = list(pagerank.values())
    print(f"     Average: {np.mean(pagerank_values):.6f}")
    
    print("\n4. COMMUNITY DETECTION:")
    try:
        # Use simple degree-based communities
        deg_values = [G.degree(node) for node in G.nodes()]
        if deg_values:
            q1 = np.percentile(deg_values, 25)
            q2 = np.percentile(deg_values, 50)
            q3 = np.percentile(deg_values, 75)
            
            communities = {}
            for node in G.nodes():
                deg = G.degree(node)
                if deg <= q1:
                    communities[node] = 0
                elif deg <= q2:
                    communities[node] = 1
                elif deg <= q3:
                    communities[node] = 2
                else:
                    communities[node] = 3
            
            nx.set_node_attributes(G, communities, 'community')
            community_sizes = np.bincount(list(communities.values()))
            print(f"    Number of communities: {len(set(communities.values()))}")
            for i, size in enumerate(community_sizes):
                print(f"     Community {i}: {size} nodes")
    except Exception as e:
        print(f"    Community detection failed: {str(e)[:50]}...")
        for node in G.nodes():
            G.nodes[node]['community'] = 0
    
    print("\n5. OVERALL GRAPH STATISTICS:")
    print(f"    Total nodes: {G.number_of_nodes()}")
    print(f"    Total edges: {G.number_of_edges()}")
    print(f"    Graph density: {nx.density(G):.6f}")
    print(f"    Is connected: {nx.is_connected(G)}")
    
    print("="*60)
    
    print("\nSAVING ALL NODE METRICS TO CSV FILE...")
    
    # Prepare data for CSV
    nodes_data = []
    for node in sorted(G.nodes()):
        node_data = {
            'node_id': node,
            'degree': G.nodes[node]['degree'],
            'clustering': G.nodes[node]['clustering'],
            'degree_centrality': G.nodes[node]['degree_centrality'],
            'betweenness': G.nodes[node]['betweenness'],
            'eigenvector': G.nodes[node]['eigenvector'],
            'pagerank': G.nodes[node]['pagerank'],
            'community': G.nodes[node]['community']
        }
        nodes_data.append(node_data)
    
    # Convert to DataFrame and save as CSV
    df = pd.DataFrame(nodes_data)
    csv_filename = "node_metrics.csv"
    df.to_csv(csv_filename, index=False)
    

    # Also save some summary statistics
    summary_data = {
        'metric': ['average_degree', 'average_clustering', 'average_degree_centrality', 
                  'average_betweenness', 'average_eigenvector', 'average_pagerank',
                  'total_nodes', 'total_edges', 'graph_density', 'is_connected'],
        'value': [np.mean(degree_values), avg_clustering, np.mean(deg_centrality_values),
                 np.mean(betweenness_values), np.mean(eigenvector_values), np.mean(pagerank_values),
                 G.number_of_nodes(), G.number_of_edges(), nx.density(G), int(nx.is_connected(G))]
    }
    
    summary_df = pd.DataFrame(summary_data)
    summary_csv = "graph_summary.csv"
    summary_df.to_csv(summary_csv, index=False)
    print(f"✓ Saved graph summary to '{summary_csv}'")
    
    print("="*60)
    return G

def create_bot_labels(G, bot_ratio=0.25):
    """Create synthetic bot labels based on graph metrics"""
    nodes = list(G.nodes())
    
    # Calculate suspiciousness scores
    scores = []
    for node in nodes:
        score = 0
        
        # High degree but low eigenvector centrality
        eigenvector_vals = [G.nodes[n]['eigenvector'] for n in nodes]
        deg_vals = [G.nodes[n]['degree'] for n in nodes]
        
        if (G.nodes[node]['degree'] > np.percentile(deg_vals, 75) and 
            G.nodes[node]['eigenvector'] < np.percentile(eigenvector_vals, 30)):
            score += 3
        
        # Low clustering coefficient relative to degree
        if G.nodes[node]['degree'] < 3:
            score += 2
        
        # High betweenness but low degree
        betweenness_vals = [G.nodes[n]['betweenness'] for n in nodes]
        if (G.nodes[node]['betweenness'] > np.percentile(betweenness_vals, 80) and 
            G.nodes[node]['degree'] < 5):
            score += 2
        
        # Low pagerank but moderate degree
        pagerank_vals = [G.nodes[n]['pagerank'] for n in nodes]
        if (G.nodes[node]['pagerank'] < np.percentile(pagerank_vals, 25) and 
            G.nodes[node]['degree'] > np.percentile(deg_vals, 50)):
            score += 2
        
        scores.append((node, score))
    
    # Sort by suspiciousness
    scores.sort(key=lambda x: x[1], reverse=True)
    
    # Select top nodes as bots
    num_bots = int(len(nodes) * bot_ratio)
    bot_nodes = [node for node, _ in scores[:num_bots]]
    
    # Create labels
    labels = {node: 1 if node in bot_nodes else 0 for node in nodes}
    
    # Ensure we have enough bots for training
    bot_count = sum(labels.values())
    print(f"\nBot Creation Summary:")
    print(f" Created {bot_count} bots out of {len(nodes)} nodes")
    
    return labels, bot_nodes

def prepare_gnn_data(G, labels):
    """Prepare data for GNN models with all features"""
    # All computed features
    feature_names = ['degree', 'clustering', 'degree_centrality', 
                    'betweenness', 'eigenvector', 'pagerank', 'community']
    
    # Create feature matrix
    features = []
    for node in sorted(G.nodes()):
        node_features = []
        for feat in feature_names:
            val = G.nodes[node].get(feat, 0)
            node_features.append(float(val))
        features.append(node_features)
    
    features = torch.tensor(features, dtype=torch.float)
    
    # Normalize features
    features = (features - features.mean(dim=0)) / (features.std(dim=0) + 1e-8)
    
    # Edge index
    edges = list(G.edges())
    edge_index = torch.tensor(edges).t().contiguous()
    
    # Labels
    y = torch.tensor([labels[node] for node in sorted(G.nodes())], dtype=torch.long)
    
    # Train/Val/Test split with stratified sampling
    num_nodes = len(G.nodes())
    
    # Get indices for bots and humans
    bot_indices = [i for i, node in enumerate(sorted(G.nodes())) if labels[node] == 1]
    human_indices = [i for i, node in enumerate(sorted(G.nodes())) if labels[node] == 0]
    
    # Shuffle
    random.shuffle(bot_indices)
    random.shuffle(human_indices)
    
    # Calculate split sizes
    train_bot_size = int(0.7 * len(bot_indices))
    val_bot_size = int(0.15 * len(bot_indices))
    
    train_human_size = int(0.7 * len(human_indices))
    val_human_size = int(0.15 * len(human_indices))
    
    # Create masks
    train_mask = torch.zeros(num_nodes, dtype=torch.bool)
    val_mask = torch.zeros(num_nodes, dtype=torch.bool)
    test_mask = torch.zeros(num_nodes, dtype=torch.bool)
    
    # Assign indices to masks
    train_indices = (bot_indices[:train_bot_size] + human_indices[:train_human_size])
    val_indices = (bot_indices[train_bot_size:train_bot_size+val_bot_size] + 
                   human_indices[train_human_size:train_human_size+val_human_size])
    test_indices = (bot_indices[train_bot_size+val_bot_size:] + 
                    human_indices[train_human_size+val_human_size:])
    
    train_mask[train_indices] = True
    val_mask[val_indices] = True
    test_mask[test_indices] = True
    
    print(f"\nGNN Data Preparation:")
    print(f" Features: {features.shape[1]} features")
    print(f" Training nodes: {train_mask.sum().item()}")
    print(f" Test nodes: {test_mask.sum().item()}")
    
    return Data(x=features, edge_index=edge_index, y=y,
                train_mask=train_mask, val_mask=val_mask, test_mask=test_mask)


class GCNBotDetector(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, dropout=0.3):
        super().__init__()
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels // 2)
        self.conv3 = GCNConv(hidden_channels // 2, out_channels)
        self.dropout = dropout
    
    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        
        x = self.conv3(x, edge_index)
        return F.log_softmax(x, dim=1)

class GraphSAGEBotDetector(nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, dropout=0.3):
        super().__init__()
        self.conv1 = SAGEConv(in_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, hidden_channels // 2)
        self.conv3 = SAGEConv(hidden_channels // 2, out_channels)
        self.dropout = dropout
    
    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        
        x = self.conv3(x, edge_index)
        return F.log_softmax(x, dim=1)

def train_and_evaluate(model, data, model_name, epochs=50):
    """Train and evaluate a GNN model with class weighting"""
    # Calculate class weights for imbalanced data
    class_counts = torch.bincount(data.y[data.train_mask])
    class_weights = 1.0 / class_counts.float()
    class_weights = class_weights / class_weights.sum()
    
    criterion = nn.NLLLoss(weight=class_weights)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=1e-4)
    
    print(f"\nTraining {model_name}...")
    
    for epoch in range(1, epochs + 1):
        model.train()
        optimizer.zero_grad()
        out = model(data.x, data.edge_index)
        loss = criterion(out[data.train_mask], data.y[data.train_mask])
        loss.backward()
        optimizer.step()
        
        if epoch % 10 == 0:
            model.eval()
            with torch.no_grad():
                out = model(data.x, data.edge_index)
                pred = out.argmax(dim=1)
                
                true = data.y[data.val_mask]
                pred_masked = pred[data.val_mask]
                
                acc = (pred_masked == true).sum().item() / true.size(0)
                
                print(f"  Epoch {epoch:03d}, Loss: {loss:.4f}, Val Acc: {acc:.4f}")
    
    # Final test evaluation
    model.eval()
    with torch.no_grad():
        out = model(data.x, data.edge_index)
        pred = out.argmax(dim=1)
        
        true = data.y[data.test_mask]
        pred_masked = pred[data.test_mask]
        
        acc = (pred_masked == true).sum().item() / true.size(0)
        
        print(f"\n{model_name} Results:")
        print(f"  Test Accuracy: {acc:.4f}")
    
    return acc

def structural_evasion_attack(G, bot_nodes):
    """Structural evasion: bots modify connections to appear normal"""
    print("\n" + "="*60)
    print("STRUCTURAL EVASION ATTACK")
    print("="*60)
    
    G_attacked = G.copy()
    changes = {'removed': 0, 'added': 0}
    
    for bot in bot_nodes:
        # Remove connections to other bots
        neighbors = list(G_attacked.neighbors(bot))
        bot_neighbors = [n for n in neighbors if n in bot_nodes]
        
        if bot_neighbors:
            to_remove = min(2, len(bot_neighbors))
            remove = random.sample(bot_neighbors, to_remove)
            for n in remove:
                G_attacked.remove_edge(bot, n)
                changes['removed'] += 1
        
        # Add connections to humans
        humans = [n for n in G_attacked.nodes() if n not in bot_nodes]
        potential = [h for h in humans if not G_attacked.has_edge(bot, h)]
        
        if potential:
            to_add = min(3, len(potential))
            add = random.sample(potential, to_add)
            for n in add:
                G_attacked.add_edge(bot, n)
                changes['added'] += 1
    
    print(f"Edges removed: {changes['removed']}")
    print(f"Edges added: {changes['added']}")
    print(f"Original edges: {G.number_of_edges()}")
    print(f"New edges: {G_attacked.number_of_edges()}")
    
    return G_attacked

def graph_poisoning_attack(G, bot_nodes):
    """Graph poisoning: attackers inject fake edges"""
    print("\n" + "="*60)
    print("GRAPH POISONING ATTACK")
    print("="*60)
    
    G_attacked = G.copy()
    changes = {'bot_bot': 0, 'bot_human': 0}
    
    # Create bot communities
    for i, b1 in enumerate(bot_nodes):
        for b2 in bot_nodes[i+1:min(i+3, len(bot_nodes))]:
            if not G_attacked.has_edge(b1, b2):
                G_attacked.add_edge(b1, b2)
                changes['bot_bot'] += 1
    
    # Connect bots to humans
    humans = [n for n in G_attacked.nodes() if n not in bot_nodes]
    for bot in bot_nodes[:len(bot_nodes)//2]:
        potential = [h for h in humans if not G_attacked.has_edge(bot, h)]
        if potential:
            to_add = min(2, len(potential))
            add = random.sample(potential, to_add)
            for h in add:
                G_attacked.add_edge(bot, h)
                changes['bot_human'] += 1
    
    print(f"Bot-bot edges added: {changes['bot_bot']}")
    print(f"Bot-human edges added: {changes['bot_human']}")
    print(f"Original edges: {G.number_of_edges()}")
    print(f"New edges: {G_attacked.number_of_edges()}")
    
    return G_attacked

def visualize_graphs(G_original, G_evasion, G_poisoning, labels):
    """Create graph visualization only"""
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    graphs = [G_original, G_evasion, G_poisoning]
    titles = ['Original Graph', 'After Evasion Attack', 'After Poisoning Attack']
    
    for idx, (G, title, ax) in enumerate(zip(graphs, titles, axes)):
        # Sample 100 nodes for visualization
        if G.number_of_nodes() > 100:
            sample_nodes = random.sample(list(G.nodes()), 100)
            G_sample = G.subgraph(sample_nodes).copy()
            labels_sample = {n: labels.get(n, 0) for n in sample_nodes}
        else:
            G_sample = G
            labels_sample = labels
        
        # Node colors
        node_colors = ['red' if labels_sample.get(node, 0) == 1 else 'blue' 
                      for node in G_sample.nodes()]
        
        # Node sizes based on degree
        node_sizes = [G_sample.degree(node) * 10 + 10 for node in G_sample.nodes()]
        
        # Layout
        pos = nx.spring_layout(G_sample, seed=42, k=0.5, iterations=50)
        
        # Draw
        nx.draw_networkx_nodes(G_sample, pos, node_color=node_colors, 
                              node_size=node_sizes, alpha=0.8, ax=ax)
        nx.draw_networkx_edges(G_sample, pos, alpha=0.2, width=0.5, ax=ax)
        
        # Add legend for first subplot only
        if idx == 0:
            legend_elements = [
                Patch(facecolor='red', alpha=0.8, label='Bots'),
                Patch(facecolor='blue', alpha=0.8, label='Humans')
            ]
            ax.legend(handles=legend_elements, loc='upper right')
        
        ax.set_title(f"{title}\nNodes: {G_sample.number_of_nodes()}, Edges: {G_sample.number_of_edges()}")
        ax.axis('off')
    
    plt.suptitle('Social Network Graph Visualization Before and After Attacks', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.show()

# ========== 9. MAIN PIPELINE ==========
def main():
    print("="*60)
    print("SOCIAL NETWORK BOT DETECTION WITH GNN MODELS")
    print("="*60)
    
    # Set random seeds
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    
    # ========== STEP 1: Load and prepare data ==========
    print("\nSTEP 1: Loading and preparing data")
    print("-"*50)
    
    edges = load_facebook_data()
    connected_edges = get_connected_component(edges, target_size=600)
    
    # ========== STEP 2: Create graph with all metrics ==========
    print("\n\nSTEP 2: Computing essential graph metrics")
    print("-"*50)
    G_original = create_graph_with_metrics(connected_edges)
    
    # ========== STEP 3: Create bot labels ==========
    print("\n\nSTEP 3: Creating synthetic bot labels")
    print("-"*50)
    labels, bot_nodes = create_bot_labels(G_original, bot_ratio=0.25)
    
    # ========== STEP 4: Prepare GNN data ==========
    print("\n\nSTEP 4: Preparing data for GNN models")
    print("-"*50)
    data_original = prepare_gnn_data(G_original, labels)
    
    # ========== STEP 5: BASELINE TRAINING ==========
    print("\n\n" + "="*60)
    print("BASELINE: Training without attacks")
    print("="*60)
    
    gcn_baseline = GCNBotDetector(data_original.x.shape[1], 32, 2, dropout=0.3)
    sage_baseline = GraphSAGEBotDetector(data_original.x.shape[1], 32, 2, dropout=0.3)
    
    baseline_results = {
        'GCN': train_and_evaluate(gcn_baseline, data_original, "GCN Baseline", epochs=50),
        'GraphSAGE': train_and_evaluate(sage_baseline, data_original, "GraphSAGE Baseline", epochs=50)
    }
    
    # ========== STEP 6: STRUCTURAL EVASION ATTACK ==========
    print("\n\n" + "="*60)
    print("ATTACK 1: Structural Evasion")
    print("="*60)
    
    G_evasion = structural_evasion_attack(G_original, bot_nodes)
    data_evasion = prepare_gnn_data(G_evasion, labels)
    
    gcn_evasion = GCNBotDetector(data_evasion.x.shape[1], 32, 2, dropout=0.3)
    sage_evasion = GraphSAGEBotDetector(data_evasion.x.shape[1], 32, 2, dropout=0.3)
    
    evasion_results = {
        'GCN': train_and_evaluate(gcn_evasion, data_evasion, "GCN (Evasion)", epochs=50),
        'GraphSAGE': train_and_evaluate(sage_evasion, data_evasion, "GraphSAGE (Evasion)", epochs=50)
    }
    
    # ========== STEP 7: GRAPH POISONING ATTACK ==========
    print("\n\n" + "="*60)
    print("ATTACK 2: Graph Poisoning")
    print("="*60)
    
    G_poisoning = graph_poisoning_attack(G_original, bot_nodes)
    data_poisoning = prepare_gnn_data(G_poisoning, labels)
    
    gcn_poisoning = GCNBotDetector(data_poisoning.x.shape[1], 32, 2, dropout=0.3)
    sage_poisoning = GraphSAGEBotDetector(data_poisoning.x.shape[1], 32, 2, dropout=0.3)
    
    poisoning_results = {
        'GCN': train_and_evaluate(gcn_poisoning, data_poisoning, "GCN (Poisoning)", epochs=50),
        'GraphSAGE': train_and_evaluate(sage_poisoning, data_poisoning, "GraphSAGE (Poisoning)", epochs=50)
    }
    
    # ========== STEP 8: GRAPH VISUALIZATION ==========
    print("\n\n" + "="*60)
    print("GRAPH VISUALIZATION")
    print("="*60)
    
    visualize_graphs(G_original, G_evasion, G_poisoning, labels)
    
    # ========== STEP 9: FINAL RESULTS SUMMARY ==========
    print("\n" + "="*60)
    print("FINAL RESULTS SUMMARY")
    print("="*60)
    
    print(f"\n{'Model':<12} {'Scenario':<20} {'Accuracy':<10}")
    print("-"*42)
    
    for model in ['GCN', 'GraphSAGE']:
        for scenario, results in [('Baseline', baseline_results),
                                 ('After Evasion', evasion_results),
                                 ('After Poisoning', poisoning_results)]:
            acc = results[model]
            print(f"{model:<12} {scenario:<20} {acc:<10.4f}")
    
    print("\n" + "="*60)
    print("ANALYSIS COMPLETE")
    print("="*60)

if __name__ == "__main__":
    main()
